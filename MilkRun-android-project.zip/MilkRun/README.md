# Молочный забег (Android)

1. Открой папку MilkRun в Android Studio (Hedgehog или новее).
2. Дай ей синкнуться с Gradle (Android Studio сама сгенерит wrapper).
3. Build > Build Bundle(s) / APK(s) > Build APK(s). Или Run на телефон.

Игра лежит в app/src/main/assets/www/index.html. Чтобы обновить игру, замени этот файл.
Для релиза в Google Play: Build > Generate Signed Bundle, потом подпиши ключом.
